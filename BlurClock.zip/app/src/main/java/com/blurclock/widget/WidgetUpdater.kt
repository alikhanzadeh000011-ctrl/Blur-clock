package com.blurclock.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Build
import android.widget.RemoteViews

object WidgetUpdater {
    const val ACTION_TICK = "com.blurclock.widget.TICK"

    fun updateAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, ClockWidgetProvider::class.java))
        if (ids.isEmpty()) {
            cancel(ctx)
            return
        }
        val s = ClockSettings(ctx)
        val fill = if (s.blurOn && s.fillFile().exists()) {
            try {
                BitmapFactory.decodeFile(s.fillFile().absolutePath)
            } catch (e: Exception) {
                null
            }
        } else null
        val bmp = ClockRenderer.render(ctx, s, fill)
        // No click intent is set on purpose: tapping the widget does nothing.
        val rv = RemoteViews(ctx.packageName, R.layout.widget)
        rv.setImageViewBitmap(R.id.img, bmp)
        mgr.updateAppWidget(ids, rv)
        schedule(ctx)
    }

    private fun pending(ctx: Context): PendingIntent {
        val i = Intent(ctx, ClockWidgetProvider::class.java).setAction(ACTION_TICK)
        return PendingIntent.getBroadcast(ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val t = (System.currentTimeMillis() / 60000 + 1) * 60000 + 300
        val pi = pending(ctx)
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC, t, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC, t, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC, t, pi)
        }
    }

    fun cancel(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(ctx))
    }
}
