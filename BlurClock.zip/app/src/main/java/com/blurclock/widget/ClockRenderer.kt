package com.blurclock.widget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

object ClockRenderer {

    fun widgetWidth(s: ClockSettings) = (s.widthFrac * s.wallW).roundToInt().coerceAtLeast(2)
    fun widgetHeight(s: ClockSettings) = (s.heightFrac * s.wallH).roundToInt().coerceAtLeast(2)

    /**
     * Draws the transparent widget image: date on top, clock below.
     * If fill is given the clock digits are filled with it (blur look), otherwise plain white.
     * Digits are drawn at the exact size set by the user, nothing is auto-shrunk.
     */
    fun render(ctx: Context, s: ClockSettings, fill: Bitmap?): Bitmap {
        val w = widgetWidth(s)
        val h = widgetHeight(s)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val now = Date()

        val dateP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            textSize = s.dateSize * s.wallW
            typeface = Fonts.date(ctx)
        }
        val dateText = SimpleDateFormat("EEE, MMMM d", Locale.ENGLISH).format(now)
        val dm = dateP.fontMetrics
        val dateBaseline = -dm.ascent
        c.drawText(dateText, w / 2f, dateBaseline, dateP)
        val dateBottom = dateBaseline + dm.descent

        val clockP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            textSize = s.clockSize * s.wallW
            textScaleX = s.clockScaleX
            typeface = Fonts.clock(ctx)
        }
        val clockText = SimpleDateFormat("hh:mm", Locale.ENGLISH).format(now) // 12h with leading zero
        val ref = Rect()
        clockP.getTextBounds("0123456789", 0, 10, ref)
        val baseline = dateBottom + s.gap * s.wallH - ref.top

        if (fill != null) {
            val mask = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            Canvas(mask).drawText(clockText, w / 2f, baseline, clockP)
            val layer = c.saveLayer(0f, 0f, w.toFloat(), h.toFloat(), null)
            c.drawBitmap(fill, null, Rect(0, 0, w, h), null)
            val maskPaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
            c.drawBitmap(mask, 0f, 0f, maskPaint)
            c.restoreToCount(layer)
            mask.recycle()
        } else {
            c.drawText(clockText, w / 2f, baseline, clockP)
        }
        return bmp
    }
}
