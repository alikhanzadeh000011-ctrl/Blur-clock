package com.blurclock.widget

import android.content.Context
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File

@Suppress("DEPRECATION")
fun realScreenSize(ctx: Context): Pair<Int, Int> {
    val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    val dm = DisplayMetrics()
    wm.defaultDisplay.getRealMetrics(dm)
    return Pair(minOf(dm.widthPixels, dm.heightPixels), maxOf(dm.widthPixels, dm.heightPixels))
}

class ClockSettings(private val ctx: Context) {
    private val p = ctx.getSharedPreferences("clock", Context.MODE_PRIVATE)

    var wallW = 0
    var wallH = 0
    var posX = 0.025f        // widget left, fraction of screen width
    var posY = 0.12f         // widget top, fraction of screen height
    var widthFrac = 0.95f    // widget width, fraction of screen width
    var heightFrac = 0.38f   // widget height, fraction of screen height
    var clockSize = 0.95f    // clock text size, fraction of screen width
    var clockScaleX = 1f     // horizontal stretch of clock digits
    var dateSize = 0.055f    // date text size, fraction of screen width
    var gap = 0.01f          // gap between date and clock, fraction of screen height
    var blurOn = true
    var blur = 60            // 0..100
    var white = 55           // 0..100

    init {
        load()
    }

    fun load() {
        val (sw, sh) = realScreenSize(ctx)
        wallW = p.getInt("wallW", sw)
        wallH = p.getInt("wallH", sh)
        posX = p.getFloat("posX", posX)
        posY = p.getFloat("posY", posY)
        widthFrac = p.getFloat("widthFrac", widthFrac)
        heightFrac = p.getFloat("heightFrac", heightFrac)
        clockSize = p.getFloat("clockSize", clockSize)
        clockScaleX = p.getFloat("clockScaleX", clockScaleX)
        dateSize = p.getFloat("dateSize", dateSize)
        gap = p.getFloat("gap", gap)
        blurOn = p.getBoolean("blurOn", blurOn)
        blur = p.getInt("blur", blur)
        white = p.getInt("white", white)
    }

    fun save() {
        p.edit()
            .putInt("wallW", wallW).putInt("wallH", wallH)
            .putFloat("posX", posX).putFloat("posY", posY)
            .putFloat("widthFrac", widthFrac).putFloat("heightFrac", heightFrac)
            .putFloat("clockSize", clockSize).putFloat("clockScaleX", clockScaleX)
            .putFloat("dateSize", dateSize).putFloat("gap", gap)
            .putBoolean("blurOn", blurOn).putInt("blur", blur).putInt("white", white)
            .apply()
    }

    fun clampPos() {
        posX = posX.coerceIn(0f, maxOf(0f, 1f - widthFrac))
        posY = posY.coerceIn(0f, maxOf(0f, 1f - heightFrac))
    }

    fun wallFile() = File(ctx.filesDir, "wall.jpg")
    fun fillFile() = File(ctx.filesDir, "fill.png")
}
