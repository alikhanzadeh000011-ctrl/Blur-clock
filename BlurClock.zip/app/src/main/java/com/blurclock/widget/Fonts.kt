package com.blurclock.widget

import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import java.io.File

object Fonts {
    private val cache = HashMap<String, Pair<Long, Typeface>>()

    private fun load(ctx: Context, name: String, fallback: Typeface): Typeface {
        val f = File(ctx.filesDir, name)
        if (!f.exists()) return fallback
        val c = cache[name]
        if (c != null && c.first == f.lastModified()) return c.second
        return try {
            val tf = Typeface.createFromFile(f)
            cache[name] = Pair(f.lastModified(), tf)
            tf
        } catch (e: Exception) {
            fallback
        }
    }

    fun clock(ctx: Context): Typeface = load(ctx, "clock_font.ttf", Typeface.DEFAULT_BOLD)

    fun date(ctx: Context): Typeface {
        val def = if (Build.VERSION.SDK_INT >= 28) Typeface.create(Typeface.DEFAULT, 500, false) else Typeface.DEFAULT_BOLD
        return load(ctx, "date_font.ttf", def)
    }

    fun import(ctx: Context, uri: Uri, name: String): Boolean {
        return try {
            ctx.contentResolver.openInputStream(uri)!!.use { input ->
                File(ctx.filesDir, name).outputStream().use { out -> input.copyTo(out) }
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun reset(ctx: Context) {
        File(ctx.filesDir, "clock_font.ttf").delete()
        File(ctx.filesDir, "date_font.ttf").delete()
    }
}
