package com.blurclock.widget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/** Shows the wallpaper with the rendered clock on top; the clock can be dragged. */
class PreviewView(ctx: Context, private var ratio: Float) : View(ctx) {
    private var wall: Bitmap? = null
    private var clock: Bitmap? = null
    private var posX = 0f
    private var posY = 0f
    private var wFrac = 1f
    private var hFrac = 0.4f
    private var lastX = 0f
    private var lastY = 0f
    var onDrag: ((Float, Float) -> Unit)? = null

    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val outline = Paint().apply {
        style = Paint.Style.STROKE
        color = Color.argb(160, 255, 255, 255)
        strokeWidth = 2f
        pathEffect = android.graphics.DashPathEffect(floatArrayOf(14f, 10f), 0f)
    }

    fun set(w: Bitmap?, c: Bitmap?, s: ClockSettings) {
        val newRatio = s.wallH.toFloat() / s.wallW
        val relayout = newRatio != ratio
        ratio = newRatio
        wall = w
        clock = c
        posX = s.posX
        posY = s.posY
        wFrac = s.widthFrac
        hFrac = s.heightFrac
        if (relayout) requestLayout()
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, (w * ratio).toInt())
    }

    override fun onDraw(canvas: android.graphics.Canvas) {
        val vw = width.toFloat()
        val vh = height.toFloat()
        canvas.drawColor(0xFF2A2A2A.toInt())
        wall?.let { canvas.drawBitmap(it, null, RectF(0f, 0f, vw, vh), paint) }
        val r = RectF(posX * vw, posY * vh, (posX + wFrac) * vw, (posY + hFrac) * vh)
        clock?.let { canvas.drawBitmap(it, null, r, paint) }
        canvas.drawRect(r, outline)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x
                lastY = e.y
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (e.x - lastX) / width
                val dy = (e.y - lastY) / height
                lastX = e.x
                lastY = e.y
                val nx = (posX + dx).coerceIn(0f, maxOf(0f, 1f - wFrac))
                val ny = (posY + dy).coerceIn(0f, maxOf(0f, 1f - hFrac))
                onDrag?.invoke(nx, ny)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}
