package com.blurclock.widget

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import kotlin.math.roundToInt

object Blur {

    /** Crops the wallpaper area under the widget, blurs it and tints it with white. */
    fun buildFill(wall: Bitmap, s: ClockSettings): Bitmap {
        val w = (s.widthFrac * s.wallW).roundToInt().coerceIn(2, wall.width)
        val h = (s.heightFrac * s.wallH).roundToInt().coerceIn(2, wall.height)
        val x = (s.posX * s.wallW).roundToInt().coerceIn(0, wall.width - w)
        val y = (s.posY * s.wallH).roundToInt().coerceIn(0, wall.height - h)
        val crop = Bitmap.createBitmap(wall, x, y, w, h)

        var result: Bitmap = crop
        val radius = (s.blur * 0.35f).roundToInt()
        if (radius >= 1) {
            val small = Bitmap.createScaledBitmap(crop, maxOf(1, w / 4), maxOf(1, h / 4), true)
            val blurred = blurBitmap(small, radius)
            result = Bitmap.createScaledBitmap(blurred, w, h, true)
        }
        val out = result.copy(Bitmap.Config.ARGB_8888, true)
        if (s.white > 0) {
            val alpha = (s.white / 100f * 0.9f * 255f).roundToInt()
            Canvas(out).drawColor(Color.argb(alpha, 255, 255, 255))
        }
        return out
    }

    fun blurBitmap(src: Bitmap, radius: Int): Bitmap {
        if (radius < 1) return src
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        repeat(3) {
            pass(px, w, h, radius, true)
            pass(px, w, h, radius, false)
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    private fun pass(px: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val len = if (horizontal) w else h
        val lines = if (horizontal) h else w
        val step = if (horizontal) 1 else w
        val div = 2 * r + 1
        val tmp = IntArray(len)
        for (line in 0 until lines) {
            val start = if (horizontal) line * w else line
            var sr = 0
            var sg = 0
            var sb = 0
            for (i in -r..r) {
                val c = px[start + i.coerceIn(0, len - 1) * step]
                sr += (c shr 16) and 255
                sg += (c shr 8) and 255
                sb += c and 255
            }
            for (x in 0 until len) {
                tmp[x] = (0xFF shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val add = px[start + minOf(x + r + 1, len - 1) * step]
                val sub = px[start + maxOf(x - r, 0) * step]
                sr += ((add shr 16) and 255) - ((sub shr 16) and 255)
                sg += ((add shr 8) and 255) - ((sub shr 8) and 255)
                sb += (add and 255) - (sub and 255)
            }
            for (x in 0 until len) px[start + x * step] = tmp[x]
        }
    }
}
