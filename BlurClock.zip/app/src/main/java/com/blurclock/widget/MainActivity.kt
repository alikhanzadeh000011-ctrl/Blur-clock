package com.blurclock.widget

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.math.ceil

class MainActivity : Activity() {
    private lateinit var s: ClockSettings
    private lateinit var preview: PreviewView
    private var wall: Bitmap? = null
    private var lastFill: Bitmap? = null

    private val REQ_WALL = 1
    private val REQ_CLOCK_FONT = 2
    private val REQ_DATE_FONT = 3

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        s = ClockSettings(this)
        loadWall()

        val root = ScrollView(this)
        root.setBackgroundColor(0xFF111111.toInt())
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), dp(14), dp(14), dp(40))
        root.addView(col)

        val hint = TextView(this)
        hint.setTextColor(0xFFBBBBBB.toInt())
        hint.text = "ساعت رو روی والپیپر بکش تا جای مناسب بلر رو پیدا کنی. کادر خط‌چین، کل ویجت هست."
        col.addView(hint)

        preview = PreviewView(this, s.wallH.toFloat() / s.wallW)
        val pw = (resources.displayMetrics.widthPixels * 0.72f).toInt()
        val plp = LinearLayout.LayoutParams(pw, ViewGroup.LayoutParams.WRAP_CONTENT)
        plp.gravity = Gravity.CENTER_HORIZONTAL
        plp.topMargin = dp(10)
        plp.bottomMargin = dp(10)
        col.addView(preview, plp)
        preview.onDrag = { x, y ->
            s.posX = x
            s.posY = y
            refresh()
        }

        addButton(col, "انتخاب والپیپر از گالری") { pick("image/*", REQ_WALL) }
        addButton(col, "انتخاب فونت ساعت (ttf / otf)") { pick("*/*", REQ_CLOCK_FONT) }
        addButton(col, "انتخاب فونت تاریخ (ttf / otf)") { pick("*/*", REQ_DATE_FONT) }
        addButton(col, "فونت‌ها به حالت پیش‌فرض") {
            Fonts.reset(this)
            refresh()
        }

        val sw = Switch(this)
        sw.text = "بلر فعال (غیرفعال = اعداد کاملا سفید)"
        sw.setTextColor(Color.WHITE)
        sw.isChecked = s.blurOn
        sw.setOnCheckedChangeListener { _, checked ->
            s.blurOn = checked
            refresh()
        }
        val swLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        swLp.topMargin = dp(12)
        col.addView(sw, swLp)

        addSlider(col, "میزان بلر", 0f, 100f, s.blur.toFloat(), { it.toInt().toString() }) {
            s.blur = it.toInt()
            refresh()
        }
        addSlider(col, "سفیدی شیشه", 0f, 100f, s.white.toFloat(), { it.toInt().toString() }) {
            s.white = it.toInt()
            refresh()
        }
        addSlider(col, "اندازه ساعت", 0.1f, 2.0f, s.clockSize, { "%.2f".format(it) }) {
            s.clockSize = it
            refresh()
        }
        addSlider(col, "عرض اعداد ساعت (کشیدگی افقی)", 0.2f, 2.0f, s.clockScaleX, { "%.2f".format(it) }) {
            s.clockScaleX = it
            refresh()
        }
        addSlider(col, "اندازه تاریخ", 0.02f, 0.15f, s.dateSize, { "%.3f".format(it) }) {
            s.dateSize = it
            refresh()
        }
        addSlider(col, "فاصله تاریخ تا ساعت", -0.05f, 0.1f, s.gap, { "%.3f".format(it) }) {
            s.gap = it
            refresh()
        }
        addSlider(col, "عرض ویجت (درصد صفحه)", 0.3f, 1.0f, s.widthFrac, { "%.2f".format(it) }) {
            s.widthFrac = it
            refresh()
        }
        addSlider(col, "ارتفاع ویجت (درصد صفحه)", 0.1f, 0.7f, s.heightFrac, { "%.2f".format(it) }) {
            s.heightFrac = it
            refresh()
        }

        addButton(col, "ثبت و اعمال روی ویجت") { apply() }
        addButton(col, "اجازه آلارم دقیق (برای آپدیت هر دقیقه)") {
            if (Build.VERSION.SDK_INT >= 31) {
                try {
                    startActivity(
                        Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))
                    )
                } catch (e: Exception) {
                    toast("این گزینه در دستگاه پیدا نشد")
                }
            } else toast("نیازی نیست")
        }
        addButton(col, "تنظیمات بهینه‌سازی باتری") {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e: ActivityNotFoundException) {
                toast("این گزینه در دستگاه پیدا نشد")
            }
        }

        setContentView(root)
        refresh()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun addButton(parent: LinearLayout, text: String, onClick: () -> Unit) {
        val b = Button(this)
        b.text = text
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(6)
        parent.addView(b, lp)
    }

    private fun addSlider(
        parent: LinearLayout,
        title: String,
        min: Float,
        max: Float,
        init: Float,
        fmt: (Float) -> String,
        onChange: (Float) -> Unit
    ) {
        val label = TextView(this)
        label.setTextColor(Color.WHITE)
        label.text = "$title: ${fmt(init)}"
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(12)
        parent.addView(label, lp)

        val sb = SeekBar(this)
        sb.max = 1000
        sb.progress = (((init - min) / (max - min)) * 1000f).toInt().coerceIn(0, 1000)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = min + (max - min) * progress / 1000f
                label.text = "$title: ${fmt(v)}"
                if (fromUser) onChange(v)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        parent.addView(sb)
    }

    private fun pick(type: String, req: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = type
        @Suppress("DEPRECATION")
        startActivityForResult(i, req)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        when (requestCode) {
            REQ_WALL -> importWall(uri)
            REQ_CLOCK_FONT -> {
                if (Fonts.import(this, uri, "clock_font.ttf")) refresh() else toast("خطا در خواندن فونت")
            }
            REQ_DATE_FONT -> {
                if (Fonts.import(this, uri, "date_font.ttf")) refresh() else toast("خطا در خواندن فونت")
            }
        }
    }

    private fun importWall(uri: Uri) {
        toast("در حال آماده‌سازی والپیپر...")
        Thread {
            try {
                val (sw, sh) = realScreenSize(this)
                val src = ImageDecoder.createSource(contentResolver, uri)
                val bmp = ImageDecoder.decodeBitmap(src) { dec, info, _ ->
                    dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    val sc = maxOf(sw.toFloat() / info.size.width, sh.toFloat() / info.size.height)
                    if (sc < 1f) {
                        val tw = ceil(info.size.width * sc).toInt().coerceAtLeast(sw)
                        val th = ceil(info.size.height * sc).toInt().coerceAtLeast(sh)
                        dec.setTargetSize(tw, th)
                    }
                }
                val sc2 = maxOf(sw.toFloat() / bmp.width, sh.toFloat() / bmp.height)
                val scW = ceil(bmp.width * sc2).toInt().coerceAtLeast(sw)
                val scH = ceil(bmp.height * sc2).toInt().coerceAtLeast(sh)
                val scaled = if (scW != bmp.width || scH != bmp.height) Bitmap.createScaledBitmap(bmp, scW, scH, true) else bmp
                val out = Bitmap.createBitmap(scaled, (scW - sw) / 2, (scH - sh) / 2, sw, sh)
                s.wallFile().outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                s.wallW = sw
                s.wallH = sh
                runOnUiThread {
                    wall = out
                    refresh()
                }
            } catch (e: Exception) {
                runOnUiThread { toast("خطا در خواندن عکس") }
            }
        }.start()
    }

    private fun loadWall() {
        wall = try {
            if (s.wallFile().exists()) BitmapFactory.decodeFile(s.wallFile().absolutePath) else null
        } catch (e: Exception) {
            null
        }
        wall?.let {
            s.wallW = it.width
            s.wallH = it.height
        }
    }

    private fun refresh() {
        s.clampPos()
        val w = wall
        lastFill = if (s.blurOn && w != null) Blur.buildFill(w, s) else null
        val bmp = ClockRenderer.render(this, s, lastFill)
        preview.set(w, bmp, s)
    }

    private fun apply() {
        s.save()
        val f = lastFill
        if (s.blurOn && f != null) {
            s.fillFile().outputStream().use { f.compress(Bitmap.CompressFormat.PNG, 100, it) }
        }
        WidgetUpdater.updateAll(this)
        toast("اعمال شد")
    }
}
