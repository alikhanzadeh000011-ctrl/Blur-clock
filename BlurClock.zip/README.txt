Blur Clock - tall lock screen clock widget
1) Upload this folder's contents to a GitHub repo
2) Actions tab -> Build APK -> download artifact BlurClock-debug (app-debug.apk)
